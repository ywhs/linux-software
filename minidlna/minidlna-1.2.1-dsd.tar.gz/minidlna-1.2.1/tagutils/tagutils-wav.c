//=========================================================================
// FILENAME	: tagutils-wav.c
// DESCRIPTION	: WAV metadata reader
//=========================================================================
// Copyright (c) 2009 NETGEAR, Inc. All Rights Reserved.
// based on software from Ron Pedde's FireFly Media Server project
//=========================================================================

/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#define GET_WAV_INT32(p) ((((uint8_t)((p)[3])) << 24) |   \
			  (((uint8_t)((p)[2])) << 16) |   \
			  (((uint8_t)((p)[1])) << 8) |	   \
			  (((uint8_t)((p)[0]))))

#define GET_WAV_INT16(p) ((((uint8_t)((p)[1])) << 8) |	   \
			  (((uint8_t)((p)[0]))))
			  
#define GET_ID3_LEN(p)(((uint8_t)((p)[0])) | \
			  ((uint8_t)((p)[1])) | \
			  ((uint8_t)((p)[2])) | \
			  ((uint8_t)((p)[3])))
			  
static int read_id3tags_len(char *head)
{
	int len=0;
	unsigned char lenbuf[4];
	memcpy(lenbuf,head+4,4);

	len = GET_ID3_LEN(lenbuf);

	return len;
}

static int enc_unicode_to_utf8_one(unsigned long unic, unsigned char *pOutput,
        int outSize)
{
    //assert(pOutput != NULL);
   // assert(outSize >= 6);
 
    if ( unic <= 0x0000007F )
    {
        // * U-00000000 - U-0000007F:  0xxxxxxx
        *pOutput     = (unic & 0x7F);
        return 1;
    }
    else if ( unic >= 0x00000080 && unic <= 0x000007FF )
    {
        // * U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
        *(pOutput+1) = (unic & 0x3F) | 0x80;
        *pOutput     = ((unic >> 6) & 0x1F) | 0xC0;
        return 2;
    }
    else if ( unic >= 0x00000800 && unic <= 0x0000FFFF )
    {
        // * U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx
        *(pOutput+2) = (unic & 0x3F) | 0x80;
        *(pOutput+1) = ((unic >>  6) & 0x3F) | 0x80;
        *pOutput     = ((unic >> 12) & 0x0F) | 0xE0;
        return 3;
    }
    else if ( unic >= 0x00010000 && unic <= 0x001FFFFF )
    {
        // * U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
        *(pOutput+3) = (unic & 0x3F) | 0x80;
        *(pOutput+2) = ((unic >>  6) & 0x3F) | 0x80;
        *(pOutput+1) = ((unic >> 12) & 0x3F) | 0x80;
        *pOutput     = ((unic >> 18) & 0x07) | 0xF0;
        return 4;
    }
    else if ( unic >= 0x00200000 && unic <= 0x03FFFFFF )
    {
        // * U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
        *(pOutput+4) = (unic & 0x3F) | 0x80;
        *(pOutput+3) = ((unic >>  6) & 0x3F) | 0x80;
        *(pOutput+2) = ((unic >> 12) & 0x3F) | 0x80;
        *(pOutput+1) = ((unic >> 18) & 0x3F) | 0x80;
        *pOutput     = ((unic >> 24) & 0x03) | 0xF8;
        return 5;
    }
    else if ( unic >= 0x04000000 && unic <= 0x7FFFFFFF )
    {
        // * U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
        *(pOutput+5) = (unic & 0x3F) | 0x80;
        *(pOutput+4) = ((unic >>  6) & 0x3F) | 0x80;
        *(pOutput+3) = ((unic >> 12) & 0x3F) | 0x80;
        *(pOutput+2) = ((unic >> 18) & 0x3F) | 0x80;
        *(pOutput+1) = ((unic >> 24) & 0x3F) | 0x80;
        *pOutput     = ((unic >> 30) & 0x01) | 0xFC;
        return 6;
    }
 
    return 0;
}

static unsigned char* get_utf8_text(char *head,int text_len)
{
	unsigned long unic;
	unsigned char *text_buf = NULL, *utf8_text = NULL, utf8_buf[6];
	int i,j;
	text_buf = malloc(text_len);
	if(!text_buf)
	{
		goto out;
	}
	
	DPRINTF(E_DEBUG, L_SCANNER, "%.*s: %.*s (%d)\n", 4, head, text_len, head, text_len);
	memcpy((char *)text_buf,head,text_len);
	printf("text_buf[0]:%x\n",text_buf[0]);
	if(text_buf[0]==1){
		for(i=1;i<text_len-1;i++){
			if(text_buf[i]==0xFF || text_buf[i]==0xFE){
				if(text_buf[i+1]==0xFF || text_buf[i+1]==0xFE){
					i+=2;
					break;
				}
			}
		}

		text_buf += i;
		i = text_len - i;
		j = (i/2)*3+1;
		DPRINTF(E_DEBUG, L_SCANNER,"text_len:%d;	utf8_size:%d\n",i,j);
		utf8_text = malloc(j);
		if(!utf8_text)
		{
			free(text_buf);
			goto out;
		}
		memset(utf8_text,0,j);
		
		while(i){
			unic=0;
			memset(utf8_buf,0,6);
			memcpy(&unic,text_buf,2);
			enc_unicode_to_utf8_one(unic,utf8_buf,6);
			strncat((char *)utf8_text,(char *)utf8_buf,sizeof(utf8_buf));
			DPRINTF(E_DEBUG, L_SCANNER,"utf8_buf:%s;utf8_text:%s\n",utf8_buf,utf8_text);
			
			i -=2;
			text_buf +=2;
		}
		//for(k=0;k<j;k++)
			//printf("utf8_text:%x\n",utf8_text[k]);
		return utf8_text;
	}
out:
	utf8_text = (unsigned char*)strdup("UNKNOWN");
	return utf8_text;
}

static int
_get_wavtags(char *filename, struct song_metadata *psong)
{
	int fd;
	uint32_t len;
	unsigned char hdr[12];
	unsigned char fmt[16];
	//uint32_t chunk_data_length;
	uint32_t format_data_length = 0;
	uint32_t compression_code = 0;
	uint32_t channel_count = 0;
	uint32_t sample_rate = 0;
	uint32_t sample_bit_length = 0;
	uint32_t bit_rate;
	uint32_t data_length = 0;
	uint32_t sec, ms;

	uint32_t current_offset;
	uint32_t block_len;

	//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Getting WAV file info\n");

	if(!(fd = open(filename, O_RDONLY)))
	{
		DPRINTF(E_WARN, L_SCANNER, "Could not create file handle\n");
		return -1;
	}

	len = 12;
	if(!(len = read(fd, hdr, len)) || (len != 12))
	{
		DPRINTF(E_WARN, L_SCANNER, "Could not read wav header from %s\n", filename);
		close(fd);
		return -1;
	}

	/* I've found some wav files that have INFO tags
	 * in them... */
	if(strncmp((char*)hdr + 0, "RIFF", 4) ||
	   strncmp((char*)hdr + 8, "WAVE", 4))
	{
		DPRINTF(E_WARN, L_SCANNER, "Invalid wav header in %s\n", filename);
		close(fd);
		return -1;
	}

	//chunk_data_length = GET_WAV_INT32(hdr + 4);

	/* now, walk through the chunks */
	current_offset = 12;
	while(current_offset + 8 < psong->file_size)
	{
		len = 8;
		if(!(len = read(fd, hdr, len)) || (len != 8))
		{
			close(fd);
			DPRINTF(E_WARN, L_SCANNER, "Error reading block: %s\n", filename);
			return -1;
		}

		current_offset += 8;
		block_len = GET_WAV_INT32(hdr + 4);

		//DEBUG DPRINTF(E_DEBUG, L_SCANNER, "Read block %02x%02x%02x%02x (%c%c%c%c) of "
		//        "size 0x%08x\n",hdr[0],hdr[1],hdr[2],hdr[3],
		//        isprint(hdr[0]) ? hdr[0] : '?',
		//        isprint(hdr[1]) ? hdr[1] : '?',
		//        isprint(hdr[2]) ? hdr[2] : '?',
		//        isprint(hdr[3]) ? hdr[3] : '?',
		//        block_len);

		if(block_len > psong->file_size)
		{
			close(fd);
			DPRINTF(E_WARN, L_SCANNER, "Bad block len: %s\n", filename);
			return -1;
		}

		if(strncmp((char*)&hdr, "fmt ", 4) == 0)
		{
			//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Found 'fmt ' header\n");
			len = 16;
			if(read(fd, fmt, len) != len)
			{
				close(fd);
				DPRINTF(E_WARN, L_SCANNER, "Bad .wav file: can't read fmt: %s\n",
					filename);
				return -1;
			}

			format_data_length = block_len;
			compression_code = GET_WAV_INT16(fmt);
			channel_count = GET_WAV_INT16(fmt + 2);
			sample_rate = GET_WAV_INT32(fmt + 4);
			sample_bit_length = GET_WAV_INT16(fmt + 14);
			//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Compression code: %d\n",compression_code);
			//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Channel count:    %d\n",channel_count);
			//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Sample Rate:      %d\n",sample_rate);
			//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Sample bit length %d\n",sample_bit_length);

		}
		else if(strncmp((char*)&hdr, "data", 4) == 0)
		{
			//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Found 'data' header\n");
			data_length = block_len;
			goto next_block;
		}
		else if(strncmp((char*)&hdr, "LIST", 4) == 0)
		{
			char *tags;
			char *p;
			int off;
			uint32_t taglen;
			char **m;

			len = GET_WAV_INT32(hdr + 4);
			if(len > 65536 || len < 9)
				goto next_block;

			tags = malloc(len+1);
			if(!tags)
				goto next_block;

			if(read(fd, tags, len) < len ||
			   strncmp(tags, "INFO", 4) != 0)
			{
				free(tags);
				goto next_block;
			}
			tags[len] = '\0';

			off = 4;
			p = tags + off;
			while(off < len - 8)
			{
				taglen = GET_WAV_INT32(p + 4);

				//DEBUG DPRINTF(E_DEBUG, L_SCANNER, "%.*s: %.*s (%d)\n", 4, p, taglen, p + 8, taglen);
				m = NULL;
				if (taglen > 2048) {
					DPRINTF(E_WARN, L_SCANNER, "Ignoring long tag [%.*s] in %s\n",
				                4, p+8, filename);
				}
				else if(strncmp(p, "INAM", 4) == 0)
					m = &(psong->title);
				else if(strncmp(p, "IALB", 4) == 0 ||
				        strncmp(p, "IPRD", 4) == 0)
					m = &(psong->album);
				else if(strncmp(p, "IGRE", 4) == 0 ||
				        strncmp(p, "IGNR", 4) == 0)
					m = &(psong->genre);
				else if(strncmp(p, "ICMT", 4) == 0)
					m = &(psong->comment);
				else if(strncmp(p, "IART", 4) == 0)
					m = &(psong->contributor[ROLE_TRACKARTIST]);
				else if(strncmp(p, "IAAR", 4) == 0)
					m = &(psong->contributor[ROLE_ALBUMARTIST]);
				else if(strncmp(p, "ICOM", 4) == 0 ||
				        strncmp(p, "IMUS", 4) == 0)
					m = &(psong->contributor[ROLE_COMPOSER]);
				else if(strncasecmp(p, "ITRK", 4) == 0)
					psong->track = atoi(p + 8);
				else if(strncmp(p, "ICRD", 4) == 0 ||
				        strncmp(p, "IYER", 4) == 0)
					psong->year = atoi(p + 8);
				if(m)
				{
					*m = malloc(taglen + 1);
					strncpy(*m, p + 8, taglen);
					(*m)[taglen] = '\0';
				}

				p += taglen + 8;
				off += taglen + 8;
				/* Handle some common WAV file malformations */
				while (*p == '\0' && off < len) {
					p++;
					off++;
				}
			}
			free(tags);
		}
		//处理id3标签
		else if(strncmp((char*)&hdr, "id3", 3) == 0)
		{
			char *tags;
			char *p;
			int off,tag_frame,t = 0;
			unsigned int text_len = 0;
			unsigned char *utf8_text;

			len = GET_WAV_INT32(hdr + 4);
			if(len > 65536 || len < 9)
				goto next_block;
			//获取id3 chunk size
			tags = malloc(len+1);
			if(!tags)
				goto next_block;
			//获取id3 chunk的内容
			if(read(fd, tags, len) < len ||
				strncmp(tags, "ID3", 3) != 0)
			{
				free(tags);
				goto next_block;
			}
			tags[len] = '\0';
			//标签头长度
			tag_frame = 10;
			p = tags + tag_frame;
			while(t < len-tag_frame)
			{
				
				off = 0;
				utf8_text = NULL;
				if(strncmp(p, "TIT2", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->title = (char *)utf8_text;
				}	
				else if(strncmp(p, "TPE1", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->contributor[ROLE_ARTIST] = (char *)utf8_text;
				}
				else if(strncmp(p, "TALB", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->album = (char *)utf8_text;
				}
				else if(strncmp(p, "TRCK", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->track = atoi((char *)utf8_text);
				}
				else if(strncmp(p, "TPOS", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->disc = atoi((char *)utf8_text);
				}
				else if(strncmp(p, "TDRC", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->year = atoi((char *)utf8_text);
				}
				else if(strncmp(p, "TLEN", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->song_length = atoi((char *)utf8_text);
				}
				else if(strncmp(p, "TBPM", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->bpm = atoi((char *)utf8_text);
				}
				else if(strncmp(p, "TCMP", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->compilation = (char )atoi((char *)utf8_text);
				}
				else if(strncmp(p, "TCOM", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->contributor[ROLE_COMPOSER] = (char *)utf8_text;
				}
				else if(strncmp(p, "TCON", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->genre = (char *)utf8_text;
				}
				else if(strncmp(p, "COMM", 4) == 0){
					text_len = read_id3tags_len(p);
					utf8_text= get_utf8_text(p+tag_frame,text_len);
					off=tag_frame+text_len;
					psong->comment = (char *)utf8_text;
				}
				else{
					p++;
					t++;
				}
				p += off;
				t += off;
			}
			free(tags);
		}
next_block:
		lseek(fd, current_offset + block_len, SEEK_SET);
		current_offset += block_len;
	}
	close(fd);

	if(((format_data_length != 16) && (format_data_length != 18)) ||
	   (compression_code != 1) ||
	   (channel_count < 1))
	{
		DPRINTF(E_WARN, L_SCANNER, "Invalid wav header in %s\n", filename);
		return -1;
	}

	if( !data_length )
		data_length = psong->file_size - 44;

	bit_rate = sample_rate * channel_count * ((sample_bit_length + 7) / 8) * 8;
	psong->bitrate = bit_rate;
	psong->samplerate = sample_rate;
	psong->channels = channel_count;
	//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Data length: %d\n", data_length);
	sec = data_length / (bit_rate / 8);
	ms = ((data_length % (bit_rate / 8)) * 1000) / (bit_rate / 8);
	psong->song_length = (sec * 1000) + ms;
	//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Song length: %d\n", psong->song_length);
	//DEBUG DPRINTF(E_DEBUG,L_SCANNER,"Bit rate: %d\n", psong->bitrate);

	/* Upon further review, WAV files should be little-endian, and DLNA requires the LPCM profile to be big-endian.
	asprintf(&(psong->mime), "audio/L16;rate=%d;channels=%d", psong->samplerate, psong->channels);
	*/

	return 0;
}

static int
_get_wavfileinfo(char *filename, struct song_metadata *psong)
{
	psong->lossless = 1;
	/* Upon further review, WAV files should be little-endian, and DLNA requires the LPCM profile to be big-endian.
	asprintf(&(psong->dlna_pn), "LPCM");
	*/

	return 0;
}
